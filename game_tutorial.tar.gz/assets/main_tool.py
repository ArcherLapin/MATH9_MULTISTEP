# ==========================================
# 1. IMPORTS & PURE MATH SCALING
# ==========================================
import pygame
import random
import os
import sys
import asyncio

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

BASE_W, BASE_H = 1080, 950
curr_w, curr_h = 1080, 950

def rx(x): return int((x / BASE_W) * curr_w)
def ry(y): return int((y / BASE_H) * curr_h)
def rs(size): return max(2, int(size * min(curr_w / BASE_W, curr_h / BASE_H)))

# Module-level font helper — used everywhere instead of SysFont
FONT_PATH = "caslon.ttf"
_font_cache = {}

def get_font(size):
    scaled = rs(size)
    if scaled not in _font_cache:
        _font_cache[scaled] = pygame.font.Font(resource_path(FONT_PATH), scaled)
    return _font_cache[scaled]

# ==========================================
# 2. CLASSES (no file I/O here — safe at module level)
# ==========================================

def draw_text(surface, text, color, base_x, base_y, base_size=26):
    font = get_font(base_size)
    surface.blit(font.render(text, True, color), (rx(base_x), ry(base_y)))


def load_frames(path_template, target_size=None, scale_factor=1.0):
    frames = []
    i = 1
    while i <= 60:
        try:
            img = pygame.image.load(path_template.format(i=i))
            if target_size:
                img = pygame.transform.scale(img, target_size)
            elif scale_factor != 1.0:
                img = pygame.transform.scale(img, (
                    int(img.get_width() * scale_factor),
                    int(img.get_height() * scale_factor)
                ))
            frames.append(img)
            i += 1
        except:
            break
    return frames


class Animation:
    def __init__(self, original_frames, speed=4, loop=False):
        self.original_frames = original_frames
        self.scaled_frames = []
        self.speed = speed
        self.loop = loop
        self.timer = 0
        self.is_playing = loop
        self.last_w, self.last_h = 0, 0

    def play(self):
        self.timer = 0
        self.is_playing = True

    def draw(self, surface, base_x, base_y):
        if not self.is_playing or not self.original_frames:
            return
        global curr_w, curr_h
        if self.last_w != curr_w or self.last_h != curr_h:
            self.scaled_frames = [
                pygame.transform.scale(img, (rx(img.get_width()), ry(img.get_height())))
                for img in self.original_frames
            ]
            self.last_w, self.last_h = curr_w, curr_h

        frame_idx = self.timer // self.speed
        if frame_idx >= len(self.scaled_frames):
            if self.loop:
                self.timer = 0
                frame_idx = 0
            else:
                self.is_playing = False
                return

        surface.blit(self.scaled_frames[frame_idx], (rx(base_x), ry(base_y)))
        self.timer += 1


class QuestionBuilder:
    def __init__(self, text, *options):
        if len(options) < 5:
            raise ValueError("Question needs 5 options!")
        self.text = text
        self.answer = options[0]
        self.wrong_options = list(options[1:])
        self.times_shown = 0


class Pokemon:
    def __init__(self, faction, name, hp, max_hp, attack, defense,
                 global_hit_frames, global_heal_frames, global_firepunch_frames,
                 global_thunderbolt_frames, global_hydropump_frames,
                 global_thunder_frames, global_leaftornado_frames):
        self.faction = faction
        self.name = name
        self.hp = hp
        self.max_hp = max_hp
        self.attack = attack
        self.defense = defense
        self.moves = []

        if self.faction == 0:
            self.ui_x, self.ui_y = 575, 485
            self.img_x, self.img_y = 50, 350
            self.tb_offset_x, self.tb_offset_y = 70, 0
            scale = 0.75
        elif self.faction == 1:
            self.ui_x, self.ui_y = 150, 100
            self.img_x, self.img_y = 650, -75
            self.tb_offset_x, self.tb_offset_y = 70, 0
            scale = 1.6
        elif self.faction == 2:
            self.ui_x, self.ui_y = 150, 100
            self.img_x, self.img_y = 650, 220
            self.tb_offset_x, self.tb_offset_y = 50, -350
            scale = 0.8
        elif self.faction == 3:
            self.ui_x, self.ui_y = 150, 100
            self.img_x, self.img_y = 600, 150
            self.tb_offset_x, self.tb_offset_y = 50, -350
            scale = 1.0
        elif self.faction == 4:
            self.ui_x, self.ui_y = 150, 100
            self.img_x, self.img_y = 700, 80
            self.tb_offset_x, self.tb_offset_y = 50, -350
            scale = 1.3
        else:
            self.ui_x, self.ui_y = 150, 100
            self.img_x, self.img_y = 600, 150
            self.tb_offset_x, self.tb_offset_y = 50, -350
            scale = 1.0

        idle_frames = load_frames(
            resource_path(f'pokemon{faction}/pokemon_{faction} ({{i}}).gif'),
            scale_factor=scale
        )
        self.animations = {
            "idle":        Animation(idle_frames,                  speed=4, loop=True),
            "hit":         Animation(global_hit_frames,            speed=3, loop=False),
            "heal":        Animation(global_heal_frames,           speed=3, loop=False),
            "thunderbolt": Animation(global_thunderbolt_frames,    speed=3, loop=False),
            "firepunch":   Animation(global_firepunch_frames,      speed=4, loop=False),
            "hydropump":   Animation(global_hydropump_frames,      speed=4, loop=False),
            "thunder":     Animation(global_thunder_frames,        speed=3, loop=False),
            "leaftornado": Animation(global_leaftornado_frames,    speed=3, loop=False),
        }

        try:
            self.faint_sound = pygame.mixer.Sound(resource_path(f"pokemon{faction}/pokemon{faction}_faint.ogg"))
            self.faint_sound.set_volume(0.4)
        except:
            self.faint_sound = None

    def play_faint_sound(self):
        if self.faint_sound:
            self.faint_sound.play()

    def trigger_vfx(self, effect_data):
        if isinstance(effect_data, (list, tuple)):
            for effect in effect_data:
                if effect in self.animations:
                    self.animations[effect].play()
        elif effect_data in self.animations:
            self.animations[effect_data].play()

    def draw(self, surface):
        draw_text(surface, self.name, (255, 255, 255), self.ui_x, self.ui_y)
        ratio = max(0, self.hp / self.max_hp)

        pygame.draw.rect(surface, (255, 0, 0), (rx(self.ui_x), ry(self.ui_y + 40), rx(300), ry(12)))
        pygame.draw.rect(surface, (0, 255, 0), (rx(self.ui_x), ry(self.ui_y + 40), rx(300 * ratio), ry(12)))
        draw_text(surface, f"HP: {int(self.hp)} / {int(self.max_hp)}", (255, 255, 255), self.ui_x, self.ui_y + 60)

        self.animations["idle"].draw(surface, self.img_x, self.img_y)
        self.animations["hit"].draw(surface, self.img_x, self.img_y + 25)
        self.animations["heal"].draw(surface, self.img_x, self.img_y)
        self.animations["firepunch"].draw(surface, self.img_x - 20, self.img_y - 150)
        self.animations["thunderbolt"].draw(surface, self.img_x + self.tb_offset_x, self.img_y + self.tb_offset_y)
        self.animations["hydropump"].draw(surface, self.img_x - 50, self.img_y - 50)
        self.animations["thunder"].draw(surface, self.img_x - 50, self.img_y - 220)
        self.animations["leaftornado"].draw(surface, self.img_x - 50, self.img_y - 220)


class MessageSystem:
    def __init__(self):
        self.queue, self.current = [], ""

    def draw(self, surface):
        draw_text(surface, self.current, (255, 255, 255), 80, 750)

    def add(self, text, target=None, hp_change=0, vfx=None, sound=None):
        self.queue.append({"text": text, "target": target, "hp_change": hp_change, "vfx": vfx, "sound": sound})

    def clear(self):
        self.current = ""

    def has_active_message(self):
        return bool(self.current) or bool(self.queue)

    def update(self):
        if not self.current and self.queue:
            msg = self.queue.pop(0)
            self.current = msg["text"]
            if msg["target"] is not None:
                msg["target"].hp += msg["hp_change"]
                if msg["hp_change"] < 0:
                    if msg["vfx"]:   msg["target"].trigger_vfx(msg["vfx"])
                    if msg["sound"]: msg["sound"].play()
                elif msg["hp_change"] > 0:
                    msg["target"].trigger_vfx("heal")
                msg["target"].hp = max(0, min(msg["target"].hp, msg["target"].max_hp))


class Move:
    def __init__(self, name, power, miss_chance, crit_chance, category, vfx, sound):
        self.name = name
        self.power = power
        self.miss_chance = miss_chance
        self.crit_chance = crit_chance
        self.category = category
        self.vfx = vfx
        self.sound = sound

    def execute(self, attacker, defender, msg_sys, heal_sound_ref):
        msg_sys.add(f"{attacker.name} used {self.name}!")
        if self.category == "heal":
            msg_sys.add(f"{attacker.name} recovered HP!", target=attacker, hp_change=self.power)
            if heal_sound_ref: heal_sound_ref.play()
        elif self.category == "buff":
            attacker.attack *= self.power
            msg_sys.add(f"{attacker.name}'s Attack sharply rose!")
        else:
            damage = int(self.power * (attacker.attack / 100))
            if random.randint(1, 100) <= self.miss_chance:
                msg_sys.add(f"{attacker.name}'s Attack missed!")
            elif random.randint(1, 100) <= self.crit_chance:
                msg_sys.add(
                    f"A critical hit! It dealt {int(damage * 1.5)} damage!",
                    target=defender, hp_change=-int(damage * 1.5), vfx=self.vfx, sound=self.sound
                )
            else:
                msg_sys.add(f"It dealt {damage} damage!", target=defender, hp_change=-damage,
                            vfx=self.vfx, sound=self.sound)


class Button:
    def __init__(self, base_x, base_y, base_w, base_h):
        self.text = ""
        self.bx, self.by, self.bw, self.bh = base_x, base_y, base_w, base_h

    def draw(self, surface):
        rect = pygame.Rect(rx(self.bx), ry(self.by), rx(self.bw), ry(self.bh))
        pygame.draw.rect(surface, (150, 200, 200), rect)
        pygame.draw.rect(surface, (0, 0, 0), rect, max(1, rs(2)))

        # Start at size 24, shrink until text fits inside button
        base_size = 24
        font = get_font(base_size)
        text_surface = font.render(self.text, True, (0, 0, 0))

        if text_surface.get_width() > rect.width - rx(10):
            shrink_ratio = (rect.width - rx(10)) / text_surface.get_width()
            smaller_size = max(8, int(base_size * shrink_ratio))
            font = get_font(smaller_size)
            text_surface = font.render(self.text, True, (0, 0, 0))

        surface.blit(text_surface, text_surface.get_rect(center=rect.center))

    def clicked(self, mousepos):
        rect = pygame.Rect(rx(self.bx), ry(self.by), rx(self.bw), ry(self.bh))
        return rect.collidepoint(mousepos)


# ==========================================
# 3. QUESTION LOADER
# ==========================================

def load_questions_from_file(filename):
    loaded = []
    try:
        with open(resource_path(filename), "r") as f:
            for line in f:
                parts = line.strip().split("|")
                if len(parts) >= 6:
                    loaded.append(QuestionBuilder(parts[0], *parts[1:]))
    except:
        pass
    return loaded


# ==========================================
# 4. MUSIC HELPER
# ==========================================

MUSIC_END_EVENT = pygame.USEREVENT + 1

def play_random_track(music_pool):
    if not music_pool:
        return
    try:
        track_num = random.choice(music_pool)
        pygame.mixer.music.load(resource_path(f'music{track_num}.ogg'))
        pygame.mixer.music.set_volume(0.15)
        pygame.mixer.music.play(0)
    except pygame.error:
        pass


# ==========================================
# 5. ASYNC GAME FUNCTIONS
# ==========================================

async def level_selection_menu(screen, clock, fps, sounds, vfx_frames, message_system, game_state, buttons):
    """Shows the level select screen. Returns level_data tuple or None to quit."""

    click_sound       = sounds["click"]
    hit_sound         = sounds["hit"]
    thunderbolt_sound = sounds["thunderbolt"]
    firepunch_sound   = sounds["firepunch"]
    hydropump_sound   = sounds["hydropump"]
    leaftornado_sound = sounds["leaftornado"]

    charizard_moves = [
        Move("Tackle",       25,  0,  0, "damage", "hit",       hit_sound),
        Move("Iron Tail",    30,  9, 15, "damage", "hit",       hit_sound),
        Move("Flamethrower", 35, 15,  5, "damage", "firepunch", firepunch_sound),
        Move("Fire Punch",   30, 12, 10, "damage", "firepunch", firepunch_sound),
    ]
    blastoise_moves = [
        Move("Tackle",     25,  0,  0, "damage", "hit",       hit_sound),
        Move("Iron Tail",  30, 10, 15, "damage", "hit",       hit_sound),
        Move("Skull Bash", 30, 20, 30, "damage", "hit",       hit_sound),
        Move("Hydro Pump", 35, 30, 10, "damage", "hydropump", hydropump_sound),
    ]
    venusaur_moves = [
        Move("Bolt Strike",  30, 10, 10, "damage", ["thunder", "hit"],     thunderbolt_sound),
        Move("Body Slam",    35, 15,  5, "damage", "hit",                  hit_sound),
        Move("Skull Bash",   25,  5, 20, "damage", "hit",                  hit_sound),
        Move("Leaf Tornado", 40, 30,  5, "damage", ["leaftornado", "hit"], leaftornado_sound),
    ]
    infernape_moves = [
        Move("Iron Tail",    30,  9, 15, "damage", "hit",       hit_sound),
        Move("Body Slam",    35, 15,  5, "damage", "hit",       hit_sound),
        Move("Skull Bash",   25,  5, 20, "damage", "hit",       hit_sound),
        Move("Fire Punch",   30, 12, 10, "damage", "firepunch", firepunch_sound),
    ]

    levels_data = [
        ("Level 1: Mitosis",       "input_mitosis.txt",                     1, "Charizard", 1200, 1200, 100, 110, charizard_moves, [1, 2]),
        ("Level 2: Mutations",     "input_mutation_organelles.txt",         2, "Blastoise", 1300, 1300, 110, 100, blastoise_moves, [3, 4]),
        ("Level 3: Unit Practice", "input_mitosis_mutation_organelles.txt", 3, "Venusaur",  1400, 1400,  90, 120, venusaur_moves,  [5, 6]),
        ("Level 4: Reproduction",  "input_reproduction.txt",                4, "Infernape",  1200, 1200,  110, 100, infernape_moves,  [1, 2]),
        ("Level 5: Coming Soon",   None, None, None, 0, 0, 0, 0, None, []),
        ("Level 6: Coming Soon",   None, None, None, 0, 0, 0, 0, None, []),
    ]

    menu_buttons = []
    start_x, start_y = 120, 350
    spacing_x = 440
    btn_w, btn_h = 400, 80

    for i, data in enumerate(levels_data):
        col = i % 2
        row = i // 2
        btn = Button(start_x + col * spacing_x, start_y + row * 120, btn_w, btn_h)
        btn.text = data[0]
        btn.level_data = data
        menu_buttons.append(btn)

    while True:
        clock.tick(fps)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for btn in menu_buttons:
                    if btn.clicked(event.pos) and btn.level_data[1] is not None:
                        if click_sound: click_sound.play()
                        return btn.level_data

        screen.fill((128, 128, 128))

        # Title uses Nunito at size 50 via get_font()
        title_font = get_font(50)
        title_surface = title_font.render("Select a Biology Module", True, (0, 0, 0))
        screen.blit(title_surface, title_surface.get_rect(center=(rx(BASE_W / 2), ry(120))))

        for btn in menu_buttons:
            btn.draw(screen)

        pygame.display.update()
        await asyncio.sleep(0)


async def start_battle(screen, clock, fps, sounds, vfx_frames,
                       Player_PKMN, Enemy_PKMN, message_system, buttons,
                       question_filename, game_state):

    click_sound        = sounds["click"]
    correct_sound      = sounds["correct"]
    heal_sound         = sounds["heal"]
    MUSIC_END          = sounds["MUSIC_END"]
    current_music_pool = sounds["current_music_pool"]

    player_attack = Move("Thundershock", 20, 0, 5, "damage",
                         ["thunderbolt", "hit"], sounds["thunderbolt"])

    question_pool = [
        QuestionBuilder("Who is your student teacher?",
                        "Mr. Chung", "Ash Ketchum", "Prof. Oak", "Bill Nye", "Mrs. Colman")
    ]
    question_pool.extend(load_questions_from_file(question_filename))

    def get_new_question():
        min_shown = min(q.times_shown for q in question_pool)
        q = random.choice([q for q in question_pool if q.times_shown == min_shown])
        q.times_shown += 1
        options = [q.answer] + random.sample(q.wrong_options, 4)
        random.shuffle(options)
        return q, options

    def setup_next_question():
        game_state["question"], game_state["options"] = get_new_question()
        for i in range(5):
            buttons[i].text = game_state["options"][i]
        buttons[5].text = f"Sitrus Berry x{game_state['berries']}"

    def handle_click(mousepos):
        if message_system.has_active_message():
            if click_sound: click_sound.play()
            message_system.clear()
            return

        if game_state["turn"] == "gameover":
            game_state["run"] = False
            return

        if game_state["turn"] == "player":
            for btn in buttons:
                if btn.clicked(mousepos):
                    if click_sound: click_sound.play()

                    if "Berry" in btn.text:
                        if game_state["berries"] > 0:
                            game_state["berries"] -= 1
                            message_system.add(f"{Player_PKMN.name} ate a Sitrus Berry!")
                            message_system.add(f"{Player_PKMN.name} recovered 100 HP!",
                                               target=Player_PKMN, hp_change=100)
                            if heal_sound: heal_sound.play()
                            game_state["turn"] = "enemy"
                            setup_next_question()
                        else:
                            message_system.add("You are out of Berries!")
                        break

                    if btn.text == game_state["question"].answer:
                        message_system.add("Correct!")
                        if correct_sound: correct_sound.play()
                        player_attack.power = round(20 * (1.2 ** game_state["streak"]))
                        if game_state["streak"] > 0:
                            message_system.add(f"{Player_PKMN.name} is pumped! (+{game_state['streak'] * 20}%)")
                        player_attack.execute(Player_PKMN, Enemy_PKMN, message_system, heal_sound)
                        game_state["streak"] += 1
                    else:
                        message_system.add("Incorrect!")
                        if game_state["streak"] > 0:
                            message_system.add(f"{Player_PKMN.name} calms down (0%).")
                        game_state["streak"] = 0
                        message_system.add(
                            f"{Player_PKMN.name}{random.choice([' missed!', ' is confused.', ' zoned out.'])}"
                        )

                    game_state["turn"] = "enemy"
                    setup_next_question()
                    break

    def run_game_logic():
        message_system.update()

        if message_system.has_active_message():
            message_system.draw(screen)
        else:
            if Enemy_PKMN.hp <= 0 and game_state["turn"] != "gameover":
                for msg in [f"{Enemy_PKMN.name} fainted!", "You win!", "Thanks for playing!"]:
                    message_system.add(msg)
                Enemy_PKMN.play_faint_sound()
                game_state["turn"] = "gameover"

            elif Player_PKMN.hp <= 0 and game_state["turn"] != "gameover":
                for msg in [f"{Player_PKMN.name} fainted!", "You lost!", "Thanks for playing!"]:
                    message_system.add(msg)
                Player_PKMN.play_faint_sound()
                game_state["turn"] = "gameover"

            elif game_state["turn"] == "player":
                draw_text(screen, game_state["question"].text, (255, 255, 255), 80, 750)
                for btn in buttons:
                    btn.draw(screen)

            elif game_state["turn"] == "enemy":
                random.choice(Enemy_PKMN.moves).execute(
                    Enemy_PKMN, Player_PKMN, message_system, heal_sound
                )
                game_state["turn"] = "player"

            elif game_state["turn"] == "gameover":
                draw_text(screen, "Click anywhere to exit.", (0, 0, 0), 80, 750)

    # --- Load background images ---
    bg_img_path = resource_path('background.jpg')
    original_bg_img = pygame.image.load(bg_img_path) if os.path.exists(bg_img_path) else None

    tb_img_path = resource_path('textbox.png')
    original_tb_img = pygame.image.load(tb_img_path) if os.path.exists(tb_img_path) else None

    scaled_bg, scaled_tb = None, None

    setup_next_question()

    while game_state["run"]:
        clock.tick(fps)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_state["run"] = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                handle_click(event.pos)
            elif event.type == MUSIC_END:
                play_random_track(current_music_pool)

        if scaled_bg is None and original_bg_img:
            scaled_bg = pygame.transform.scale(original_bg_img, (curr_w, ry(720)))
        if scaled_tb is None and original_tb_img:
            scaled_tb = pygame.transform.scale(original_tb_img, (curr_w, curr_h - ry(720)))

        screen.fill((0, 0, 0))
        if scaled_bg: screen.blit(scaled_bg, (0, 0))
        pygame.draw.rect(screen, (75, 117, 155), (0, ry(720), curr_w, curr_h - ry(720)))
        if scaled_tb: screen.blit(scaled_tb, (0, ry(720)))

        Player_PKMN.draw(screen)
        Enemy_PKMN.draw(screen)
        run_game_logic()

        pygame.display.update()
        await asyncio.sleep(0)


# ==========================================
# 6. MAIN — all pygame init & resource loading goes here
# ==========================================

async def main():
    pygame.mixer.pre_init(48000, -16, 2, 4096)
    pygame.init()
    pygame.mixer.init()

    screen = pygame.display.set_mode((BASE_W, BASE_H))
    pygame.display.set_caption("Pokemon Biology Battle Game")
    clock = pygame.time.Clock()
    fps = 60

    pygame.mixer.music.set_endevent(MUSIC_END_EVENT)

    # --- Sound loading ---
    def load_sound(path, volume):
        try:
            s = pygame.mixer.Sound(resource_path(path))
            s.set_volume(volume)
            return s
        except:
            return None

    click_sound       = load_sound('click.ogg',       0.5)
    correct_sound     = load_sound('correct.ogg',     0.4)
    heal_sound        = load_sound('heal.ogg',        0.4)
    hit_sound         = load_sound('hit.ogg',         0.4)
    firepunch_sound   = load_sound('firepunch.ogg',   0.4)
    thunderbolt_sound = load_sound('thunderbolt.ogg', 0.3)
    hydropump_sound   = load_sound('hydropump.ogg',   0.4)
    leaftornado_sound = load_sound('leaftornado.ogg', 0.4)

    sounds = {
        "click":              click_sound,
        "correct":            correct_sound,
        "heal":               heal_sound,
        "hit":                hit_sound,
        "firepunch":          firepunch_sound,
        "thunderbolt":        thunderbolt_sound,
        "hydropump":          hydropump_sound,
        "leaftornado":        leaftornado_sound,
        "MUSIC_END":          MUSIC_END_EVENT,
        "current_music_pool": [],
    }

    # --- VFX frame loading ---
    global_hit_frames         = load_frames(resource_path('vfx/hit ({i}).gif'),           target_size=(400, 400))
    global_heal_frames        = load_frames(resource_path('vfx/heal ({i}).gif'),          target_size=(400, 400))
    global_firepunch_frames   = load_frames(resource_path('vfx/firepunch ({i}).gif'),     target_size=(500, 500))
    global_thunderbolt_frames = load_frames(resource_path('vfx/lightning ({i}).gif'),     target_size=(200, 500))
    global_hydropump_frames   = load_frames(resource_path('vfx/water ({i}).gif'),         target_size=(600, 600))
    global_thunder_frames     = load_frames(resource_path('vfx/green_thunder ({i}).gif'), target_size=(500, 600))
    global_leaftornado_frames = load_frames(resource_path('vfx/leaf_tornado ({i}).gif'),  target_size=(400, 600))

    vfx_frames = {
        "hit":         global_hit_frames,
        "heal":        global_heal_frames,
        "firepunch":   global_firepunch_frames,
        "thunderbolt": global_thunderbolt_frames,
        "hydropump":   global_hydropump_frames,
        "thunder":     global_thunder_frames,
        "leaftornado": global_leaftornado_frames,
    }

    # --- Player Pokemon ---
    Player_PKMN = Pokemon(
        0, "Raichu", 550, 550, 100, 100,
        global_hit_frames, global_heal_frames, global_firepunch_frames,
        global_thunderbolt_frames, global_hydropump_frames,
        global_thunder_frames, global_leaftornado_frames
    )

    # --- UI ---
    message_system = MessageSystem()
    message_system.add("Welcome to Mr. Chung's Biology Pokemon Battle!")

    buttons = [
        Button(80,  795, 290, 60), Button(395, 795, 290, 60), Button(710, 795, 290, 60),
        Button(80,  865, 290, 60), Button(395, 865, 290, 60), Button(710, 865, 290, 60),
    ]

    # --- Main loop: level select → battle → repeat ---
    while True:
        chosen = await level_selection_menu(
            screen, clock, fps, sounds, vfx_frames, message_system,
            {"turn": "player", "run": True, "streak": 0, "berries": 3, "question": None, "options": []},
            buttons
        )

        if chosen is None:
            break

        title, filename, faction, name, hp, max_hp, atk, df, moves, music_pool = chosen

        Enemy_PKMN = Pokemon(
            faction, name, hp, max_hp, atk, df,
            global_hit_frames, global_heal_frames, global_firepunch_frames,
            global_thunderbolt_frames, global_hydropump_frames,
            global_thunder_frames, global_leaftornado_frames
        )
        Enemy_PKMN.moves = moves

        sounds["current_music_pool"] = music_pool
        play_random_track(music_pool)

        Player_PKMN.hp = Player_PKMN.max_hp

        message_system.add(f"This is {title}!")

        game_state = {
            "turn": "player", "run": True,
            "streak": 0, "berries": 3,
            "question": None, "options": []
        }

        await start_battle(
            screen, clock, fps, sounds, vfx_frames,
            Player_PKMN, Enemy_PKMN, message_system, buttons,
            filename, game_state
        )

    pygame.quit()


# ==========================================
# 7. ENTRY POINT
# ==========================================

if __name__ == '__main__':
    asyncio.run(main())